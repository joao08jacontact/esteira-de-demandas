import { useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ChevronLeft, ChevronRight, ArrowUpDown, Clock, CheckCircle2, XCircle, AlertCircle } from "lucide-react";
import type { GlpiTicket } from "@shared/schema";
import { statusLabels, priorityLabels, typeLabels, formatDuration, getSLAStatus } from "@shared/schema";
import { format, isValid, parseISO } from "date-fns";
import { ptBR } from "date-fns/locale";

interface TicketsTableProps {
  tickets: GlpiTicket[] | undefined;
  isLoading: boolean;
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}

const getStatusColor = (status: number) => {
  const colors: Record<number, string> = {
    1: "bg-blue-500/10 text-blue-500 border-blue-500/20",
    2: "bg-amber-500/10 text-amber-500 border-amber-500/20",
    3: "bg-purple-500/10 text-purple-500 border-purple-500/20",
    4: "bg-green-500/10 text-green-500 border-green-500/20",
    5: "bg-gray-500/10 text-gray-500 border-gray-500/20",
  };
  return colors[status] || colors[1];
};

const getPriorityColor = (priority: number) => {
  const colors: Record<number, string> = {
    1: "bg-gray-500/10 text-gray-500 border-gray-500/20",
    2: "bg-gray-500/10 text-gray-500 border-gray-500/20",
    3: "bg-blue-500/10 text-blue-500 border-blue-500/20",
    4: "bg-orange-500/10 text-orange-500 border-orange-500/20",
    5: "bg-red-500/10 text-red-500 border-red-500/20",
    6: "bg-red-600/10 text-red-600 border-red-600/20",
  };
  return colors[priority] || colors[3];
};

const formatTicketDate = (dateString: string | null | undefined): string => {
  if (!dateString) return "N/A";
  
  try {
    // GLPI returns dates in format "YYYY-MM-DD HH:mm:ss"
    // Convert to ISO format by replacing space with "T"
    const isoString = dateString.replace(" ", "T");
    const date = parseISO(isoString);
    
    if (!isValid(date)) return "N/A";
    
    return format(date, "dd/MM/yyyy HH:mm", { locale: ptBR });
  } catch (error) {
    return "N/A";
  }
};

const getSLABadge = (ticket: GlpiTicket) => {
  const slaStatus = getSLAStatus(ticket.time_to_resolve, ticket.solvedate);
  
  if (slaStatus === "ok") {
    return (
      <Badge className="bg-green-500/10 text-green-500 border-green-500/20" data-testid={`sla-ok-${ticket.id}`}>
        <CheckCircle2 className="h-3 w-3 mr-1" />
        OK
      </Badge>
    );
  }
  
  if (slaStatus === "violated") {
    return (
      <Badge className="bg-red-500/10 text-red-500 border-red-500/20" data-testid={`sla-violated-${ticket.id}`}>
        <XCircle className="h-3 w-3 mr-1" />
        Violado
      </Badge>
    );
  }
  
  return (
    <Badge variant="outline" className="text-muted-foreground" data-testid={`sla-na-${ticket.id}`}>
      <AlertCircle className="h-3 w-3 mr-1" />
      N/A
    </Badge>
  );
};

export function TicketsTable({
  tickets,
  isLoading,
  currentPage,
  totalPages,
  onPageChange,
}: TicketsTableProps) {
  const [sortField, setSortField] = useState<keyof GlpiTicket | null>(null);
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");

  const handleSort = (field: keyof GlpiTicket) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("desc");
    }
  };

  const sortedTickets = tickets ? [...tickets].sort((a, b) => {
    if (!sortField) return 0;
    const aVal = a[sortField];
    const bVal = b[sortField];
    const direction = sortDirection === "asc" ? 1 : -1;
    if (aVal < bVal) return -1 * direction;
    if (aVal > bVal) return 1 * direction;
    return 0;
  }) : [];

  if (isLoading) {
    return (
      <Card>
        <div className="p-6 space-y-4">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="h-16 bg-muted rounded animate-pulse" />
          ))}
        </div>
      </Card>
    );
  }

  if (!tickets || tickets.length === 0) {
    return (
      <Card className="p-12">
        <div className="text-center space-y-4">
          <div className="text-6xl">📋</div>
          <h3 className="text-xl font-semibold">Nenhum ticket encontrado</h3>
          <p className="text-muted-foreground">
            Tente ajustar os filtros para ver mais resultados.
          </p>
        </div>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <Card>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[100px]">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleSort("id")}
                    className="h-8 px-2"
                    data-testid="button-sort-id"
                  >
                    ID
                    <ArrowUpDown className="ml-2 h-3 w-3" />
                  </Button>
                </TableHead>
                <TableHead>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleSort("name")}
                    className="h-8 px-2"
                    data-testid="button-sort-name"
                  >
                    Título
                    <ArrowUpDown className="ml-2 h-3 w-3" />
                  </Button>
                </TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Prioridade</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead>Atribuído a</TableHead>
                <TableHead>Tempo Resolução</TableHead>
                <TableHead>SLA</TableHead>
                <TableHead>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleSort("date")}
                    className="h-8 px-2"
                    data-testid="button-sort-date"
                  >
                    Criado em
                    <ArrowUpDown className="ml-2 h-3 w-3" />
                  </Button>
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedTickets.map((ticket, index) => (
                <TableRow
                  key={ticket.id}
                  className="hover-elevate"
                  data-testid={`row-ticket-${ticket.id}`}
                >
                  <TableCell className="font-mono text-sm" data-testid={`text-ticket-id-${ticket.id}`}>
                    #{ticket.id}
                  </TableCell>
                  <TableCell className="max-w-md truncate font-medium">
                    {ticket.name}
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant="outline"
                      className={`rounded-full ${getStatusColor(ticket.status)}`}
                      data-testid={`badge-status-${ticket.id}`}
                    >
                      {statusLabels[ticket.status]}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant="outline"
                      className={`rounded-full ${getPriorityColor(ticket.priority)}`}
                      data-testid={`badge-priority-${ticket.id}`}
                    >
                      {priorityLabels[ticket.priority]}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {typeLabels[ticket.type]}
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground" data-testid={`text-assigned-${ticket.id}`}>
                    {ticket.users_id_assign ? `Usuário #${ticket.users_id_assign}` : "-"}
                  </TableCell>
                  <TableCell className="text-sm" data-testid={`text-resolution-time-${ticket.id}`}>
                    <div className="flex items-center gap-1">
                      <Clock className="h-3 w-3 text-muted-foreground" />
                      <span className="text-muted-foreground">{formatDuration(ticket.solve_delay_stat)}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    {getSLABadge(ticket)}
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {formatTicketDate(ticket.date)}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </Card>

      {totalPages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            Página {currentPage} de {totalPages}
          </p>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => onPageChange(currentPage - 1)}
              disabled={currentPage === 1}
              data-testid="button-page-prev"
            >
              <ChevronLeft className="h-4 w-4" />
              Anterior
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => onPageChange(currentPage + 1)}
              disabled={currentPage === totalPages}
              data-testid="button-page-next"
            >
              Próxima
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
