import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import type { TicketStats } from "@shared/schema";
import { statusLabels, priorityLabels, typeLabels } from "@shared/schema";

interface ChartsSectionProps {
  stats: TicketStats | undefined;
  isLoading: boolean;
}

const STATUS_COLORS: Record<number, string> = {
  1: "hsl(210, 100%, 55%)", // New - Blue
  2: "hsl(40, 95%, 55%)", // In Progress - Amber
  3: "hsl(280, 65%, 60%)", // Pending - Purple
  4: "hsl(150, 60%, 50%)", // Solved - Green
  5: "hsl(0, 0%, 50%)", // Closed - Gray
};

const PRIORITY_COLORS: Record<number, string> = {
  1: "hsl(0, 0%, 60%)", // Very Low - Gray
  2: "hsl(0, 0%, 60%)", // Low - Gray
  3: "hsl(210, 100%, 55%)", // Medium - Blue
  4: "hsl(25, 95%, 55%)", // High - Orange
  5: "hsl(0, 85%, 60%)", // Very High - Red
  6: "hsl(0, 85%, 60%)", // Critical - Red
};

export function ChartsSection({ stats, isLoading }: ChartsSectionProps) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {[1, 2, 3, 4].map((i) => (
          <Card key={i}>
            <CardHeader>
              <div className="h-6 w-48 bg-muted rounded animate-pulse" />
            </CardHeader>
            <CardContent>
              <div className="h-64 bg-muted rounded animate-pulse" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const statusData = stats?.byStatus.map((item) => ({
    name: statusLabels[item.status],
    value: item.count,
    status: item.status,
  })) || [];

  const priorityData = stats?.byPriority.map((item) => ({
    name: priorityLabels[item.priority],
    value: item.count,
    priority: item.priority,
  })) || [];

  const typeData = stats?.byType.map((item) => ({
    name: typeLabels[item.type],
    value: item.count,
  })) || [];

  const timelineData = stats?.timeline || [];
  
  const weeklyTimelineData = stats?.weeklyTimeline || [];
  
  const resolutionTimeData = stats?.resolutionTimeDistribution || [];
  
  const assigneeData = stats?.byAssignee?.slice(0, 10).map((item) => ({
    name: item.userName,
    value: item.count,
  })) || [];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Card data-testid="card-chart-status">
        <CardHeader>
          <CardTitle className="text-base">Distribuição por Status</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie
                data={statusData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={90}
                paddingAngle={2}
                dataKey="value"
                label={({ name, percent }) =>
                  `${name}: ${(percent * 100).toFixed(0)}%`
                }
              >
                {statusData.map((entry) => (
                  <Cell
                    key={`cell-${entry.status}`}
                    fill={STATUS_COLORS[entry.status]}
                  />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card data-testid="card-chart-priority">
        <CardHeader>
          <CardTitle className="text-base">Tickets por Prioridade</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={priorityData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
              <XAxis type="number" />
              <YAxis dataKey="name" type="category" width={100} fontSize={12} />
              <Tooltip />
              <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                {priorityData.map((entry) => (
                  <Cell
                    key={`cell-${entry.priority}`}
                    fill={PRIORITY_COLORS[entry.priority]}
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card data-testid="card-chart-timeline">
        <CardHeader>
          <CardTitle className="text-base">Evolução Temporal</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={timelineData}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
              <XAxis dataKey="date" fontSize={12} />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line
                type="monotone"
                dataKey="count"
                stroke="hsl(var(--primary))"
                strokeWidth={2}
                dot={{ r: 4 }}
                name="Tickets Criados"
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card data-testid="card-chart-type">
        <CardHeader>
          <CardTitle className="text-base">Distribuição por Tipo</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={typeData}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
              <XAxis dataKey="name" fontSize={12} />
              <YAxis />
              <Tooltip />
              <Bar
                dataKey="value"
                fill="hsl(var(--chart-1))"
                radius={[4, 4, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card data-testid="card-chart-resolution-time">
        <CardHeader>
          <CardTitle className="text-base">Tempo de Resolução</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={resolutionTimeData}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
              <XAxis dataKey="range" fontSize={12} />
              <YAxis />
              <Tooltip />
              <Bar
                dataKey="count"
                fill="hsl(280, 65%, 60%)"
                radius={[4, 4, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card data-testid="card-chart-weekly">
        <CardHeader>
          <CardTitle className="text-base">Tickets por Semana (Últimas 8 Semanas)</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={weeklyTimelineData}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
              <XAxis dataKey="weekLabel" fontSize={11} angle={-45} textAnchor="end" height={80} />
              <YAxis />
              <Tooltip 
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const data = payload[0].payload;
                    return (
                      <div className="bg-background border border-border p-2 rounded shadow-lg">
                        <p className="font-medium text-sm">{data.weekLabel}</p>
                        <p className="text-xs text-muted-foreground">{data.startDate} a {data.endDate}</p>
                        <p className="text-sm font-semibold text-primary mt-1">{data.count} tickets</p>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Bar
                dataKey="count"
                fill="hsl(150, 60%, 50%)"
                radius={[4, 4, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {assigneeData.length > 0 && (
        <Card data-testid="card-chart-assignee">
          <CardHeader>
            <CardTitle className="text-base">Top 10 Técnicos (Tickets Atribuídos)</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={assigneeData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                <XAxis type="number" />
                <YAxis dataKey="name" type="category" width={120} fontSize={12} />
                <Tooltip />
                <Bar
                  dataKey="value"
                  fill="hsl(210, 100%, 55%)"
                  radius={[0, 4, 4, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
