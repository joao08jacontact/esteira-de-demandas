import { Card } from "@/components/ui/card";
import { AlertCircle, CheckCircle2, Clock, Ticket, Timer, TrendingUp, Pause, Target } from "lucide-react";
import type { TicketStats } from "@shared/schema";
import { formatDuration } from "@shared/schema";

interface KPICardsProps {
  stats: TicketStats | undefined;
  isLoading: boolean;
}

export function KPICards({ stats, isLoading }: KPICardsProps) {
  const cards = [
    {
      id: "total",
      title: "Total de Tickets",
      value: stats?.total || 0,
      displayValue: (stats?.total || 0).toLocaleString('pt-BR'),
      icon: Ticket,
      color: "text-primary",
      bgColor: "bg-primary/10",
    },
    {
      id: "new",
      title: "Novos",
      value: stats?.new || 0,
      displayValue: (stats?.new || 0).toLocaleString('pt-BR'),
      icon: AlertCircle,
      color: "text-blue-500",
      bgColor: "bg-blue-500/10",
    },
    {
      id: "in-progress",
      title: "Em Andamento",
      value: stats?.inProgress || 0,
      displayValue: (stats?.inProgress || 0).toLocaleString('pt-BR'),
      icon: Clock,
      color: "text-amber-500",
      bgColor: "bg-amber-500/10",
    },
    {
      id: "solved",
      title: "Resolvidos",
      value: stats?.solved || 0,
      displayValue: (stats?.solved || 0).toLocaleString('pt-BR'),
      icon: CheckCircle2,
      color: "text-green-500",
      bgColor: "bg-green-500/10",
    },
    {
      id: "first-response",
      title: "Tempo Médio 1ª Resposta",
      value: stats?.avgFirstResponseTime || 0,
      displayValue: formatDuration(stats?.avgFirstResponseTime),
      icon: Timer,
      color: "text-cyan-500",
      bgColor: "bg-cyan-500/10",
    },
    {
      id: "resolution",
      title: "Tempo Médio Resolução",
      value: stats?.avgResolutionTime || 0,
      displayValue: formatDuration(stats?.avgResolutionTime),
      icon: TrendingUp,
      color: "text-purple-500",
      bgColor: "bg-purple-500/10",
    },
    {
      id: "sla",
      title: "SLA Cumprido",
      value: stats?.slaCompliance ?? 0,
      displayValue: stats?.slaCompliance !== undefined && stats?.slaCompliance !== null ? `${stats.slaCompliance}%` : "-",
      icon: Target,
      color: "text-emerald-500",
      bgColor: "bg-emerald-500/10",
    },
    {
      id: "waiting",
      title: "Tickets em Espera",
      value: stats?.ticketsInWaiting || 0,
      displayValue: (stats?.ticketsInWaiting || 0).toLocaleString('pt-BR'),
      icon: Pause,
      color: "text-orange-500",
      bgColor: "bg-orange-500/10",
    },
  ];

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
          <Card key={i} className="p-6">
            <div className="animate-pulse space-y-4">
              <div className="h-10 w-10 rounded-lg bg-muted" />
              <div className="h-10 w-24 bg-muted rounded" />
              <div className="h-4 w-32 bg-muted rounded" />
            </div>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {cards.map((card) => {
        const Icon = card.icon;
        return (
          <Card
            key={card.id}
            className="p-6 hover-elevate transition-all duration-150"
            data-testid={`card-kpi-${card.id}`}
          >
            <div className="flex items-start justify-between">
              <div className="space-y-2">
                <div className={`inline-flex p-2 rounded-lg ${card.bgColor}`}>
                  <Icon className={`h-6 w-6 ${card.color}`} />
                </div>
                <div className="space-y-1">
                  <p className="text-4xl font-bold" data-testid={`text-kpi-value-${card.id}`}>
                    {card.displayValue}
                  </p>
                  <p className="text-sm text-muted-foreground font-medium">
                    {card.title}
                  </p>
                </div>
              </div>
            </div>
          </Card>
        );
      })}
    </div>
  );
}
