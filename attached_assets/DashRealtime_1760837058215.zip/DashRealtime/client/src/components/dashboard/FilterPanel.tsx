import { Search, X, Filter, Calendar } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { statusLabels, priorityLabels } from "@shared/schema";
import type { TicketFilters } from "@shared/schema";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { useQuery } from "@tanstack/react-query";

interface FilterPanelProps {
  filters: TicketFilters;
  onFiltersChange: (filters: TicketFilters) => void;
  activeFilterCount: number;
}

interface Category {
  id: number;
  name: string;
}

interface User {
  id: number;
  name: string;
}

interface Group {
  id: number;
  name: string;
}

export function FilterPanel({
  filters,
  onFiltersChange,
  activeFilterCount,
}: FilterPanelProps) {
  // Fetch categories from backend
  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
    staleTime: 1000 * 60 * 5, // Cache for 5 minutes
  });

  // Fetch users from backend
  const { data: users = [] } = useQuery<User[]>({
    queryKey: ["/api/users"],
    staleTime: 1000 * 60 * 5, // Cache for 5 minutes
  });

  // Fetch groups from backend
  const { data: groups = [] } = useQuery<Group[]>({
    queryKey: ["/api/groups"],
    staleTime: 1000 * 60 * 5, // Cache for 5 minutes
  });

  // Create category labels map from fetched data
  const categoryLabels: Record<number, string> = categories.reduce(
    (acc, cat) => {
      acc[cat.id] = cat.name;
      return acc;
    },
    {} as Record<number, string>
  );

  // Create a key that changes when filters are cleared to force Select reset
  const selectKey = JSON.stringify({
    status: filters.status?.length || 0,
    priority: filters.priority?.length || 0,
    category: filters.category?.length || 0,
    assignedTo: filters.assignedTo?.length || 0,
    assignedGroup: filters.assignedGroup?.length || 0,
  });

  const handleClearFilters = () => {
    onFiltersChange({});
  };

  const handleStatusChange = (value: string) => {
    const statusId = parseInt(value);
    const currentStatus = filters.status || [];
    const newStatus = currentStatus.includes(statusId)
      ? currentStatus.filter(s => s !== statusId)
      : [...currentStatus, statusId];
    
    onFiltersChange({
      ...filters,
      status: newStatus.length > 0 ? newStatus : undefined,
    });
  };

  const handlePriorityChange = (value: string) => {
    const priorityId = parseInt(value);
    const currentPriority = filters.priority || [];
    const newPriority = currentPriority.includes(priorityId)
      ? currentPriority.filter(p => p !== priorityId)
      : [...currentPriority, priorityId];
    
    onFiltersChange({
      ...filters,
      priority: newPriority.length > 0 ? newPriority : undefined,
    });
  };

  const handleCategoryChange = (value: string) => {
    const categoryId = parseInt(value);
    const currentCategory = filters.category || [];
    const newCategory = currentCategory.includes(categoryId)
      ? currentCategory.filter(c => c !== categoryId)
      : [...currentCategory, categoryId];
    
    onFiltersChange({
      ...filters,
      category: newCategory.length > 0 ? newCategory : undefined,
    });
  };

  const handleDateFromChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onFiltersChange({
      ...filters,
      dateFrom: e.target.value || undefined,
    });
  };

  const handleDateToChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onFiltersChange({
      ...filters,
      dateTo: e.target.value || undefined,
    });
  };

  const handleClearDateFrom = () => {
    onFiltersChange({
      ...filters,
      dateFrom: undefined,
    });
  };

  const handleClearDateTo = () => {
    onFiltersChange({
      ...filters,
      dateTo: undefined,
    });
  };

  const handleAssignedToChange = (value: string) => {
    const userId = parseInt(value);
    const currentAssignedTo = filters.assignedTo || [];
    const newAssignedTo = currentAssignedTo.includes(userId)
      ? currentAssignedTo.filter(u => u !== userId)
      : [...currentAssignedTo, userId];
    
    onFiltersChange({
      ...filters,
      assignedTo: newAssignedTo.length > 0 ? newAssignedTo : undefined,
    });
  };

  const handleAssignedGroupChange = (value: string) => {
    const groupId = parseInt(value);
    const currentAssignedGroup = filters.assignedGroup || [];
    const newAssignedGroup = currentAssignedGroup.includes(groupId)
      ? currentAssignedGroup.filter(g => g !== groupId)
      : [...currentAssignedGroup, groupId];
    
    onFiltersChange({
      ...filters,
      assignedGroup: newAssignedGroup.length > 0 ? newAssignedGroup : undefined,
    });
  };

  return (
    <div className="sticky top-16 z-40 border-b bg-muted/30 backdrop-blur supports-[backdrop-filter]:bg-muted/20">
      <div className="px-4 lg:px-8 py-4">
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-2 text-sm font-medium">
            <Filter className="h-4 w-4" />
            <span>Filtros</span>
            {activeFilterCount > 0 && (
              <Badge variant="secondary" data-testid="badge-filter-count">
                {activeFilterCount}
              </Badge>
            )}
          </div>

          <div className="relative flex-1 min-w-[200px] max-w-xs">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar tickets..."
              value={filters.search || ""}
              onChange={(e) =>
                onFiltersChange({
                  ...filters,
                  search: e.target.value || undefined,
                })
              }
              className="pl-9"
              data-testid="input-search"
            />
          </div>

          <Select key={`status-${selectKey}`} onValueChange={handleStatusChange}>
            <SelectTrigger className="w-[180px]" data-testid="select-status">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              {Object.entries(statusLabels).map(([id, label]) => (
                <SelectItem key={id} value={id}>
                  {label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select key={`priority-${selectKey}`} onValueChange={handlePriorityChange}>
            <SelectTrigger className="w-[180px]" data-testid="select-priority">
              <SelectValue placeholder="Prioridade" />
            </SelectTrigger>
            <SelectContent>
              {Object.entries(priorityLabels).map(([id, label]) => (
                <SelectItem key={id} value={id}>
                  {label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select key={`category-${selectKey}`} onValueChange={handleCategoryChange}>
            <SelectTrigger className="w-[180px]" data-testid="select-category">
              <SelectValue placeholder="Categoria" />
            </SelectTrigger>
            <SelectContent>
              {Object.entries(categoryLabels).map(([id, label]) => (
                <SelectItem key={id} value={id}>
                  {label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select key={`assignedTo-${selectKey}`} onValueChange={handleAssignedToChange}>
            <SelectTrigger className="w-[180px]" data-testid="select-assigned-to">
              <SelectValue placeholder="Atribuído a" />
            </SelectTrigger>
            <SelectContent>
              {users.map((user) => (
                <SelectItem key={user.id} value={user.id.toString()}>
                  {user.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select key={`assignedGroup-${selectKey}`} onValueChange={handleAssignedGroupChange}>
            <SelectTrigger className="w-[180px]" data-testid="select-assigned-group">
              <SelectValue placeholder="Grupo" />
            </SelectTrigger>
            <SelectContent>
              {groups.map((group) => (
                <SelectItem key={group.id} value={group.id.toString()}>
                  {group.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className="w-[200px] justify-start text-left font-normal"
                data-testid="button-date-filter"
              >
                <Calendar className="mr-2 h-4 w-4" />
                {filters.dateFrom || filters.dateTo ? (
                  <span>
                    {filters.dateFrom && format(new Date(filters.dateFrom), "dd/MM/yyyy", { locale: ptBR })}
                    {filters.dateFrom && filters.dateTo && " - "}
                    {filters.dateTo && format(new Date(filters.dateTo), "dd/MM/yyyy", { locale: ptBR })}
                  </span>
                ) : (
                  <span className="text-muted-foreground">Data</span>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-4" align="start">
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Data Inicial</label>
                  <div className="flex gap-2">
                    <Input
                      type="date"
                      value={filters.dateFrom || ""}
                      onChange={handleDateFromChange}
                      data-testid="input-date-from"
                    />
                    {filters.dateFrom && (
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={handleClearDateFrom}
                        data-testid="button-clear-date-from"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Data Final</label>
                  <div className="flex gap-2">
                    <Input
                      type="date"
                      value={filters.dateTo || ""}
                      onChange={handleDateToChange}
                      data-testid="input-date-to"
                    />
                    {filters.dateTo && (
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={handleClearDateTo}
                        data-testid="button-clear-date-to"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </PopoverContent>
          </Popover>

          {activeFilterCount > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={handleClearFilters}
              data-testid="button-clear-filters"
            >
              <X className="h-4 w-4 mr-2" />
              Limpar Filtros
            </Button>
          )}
        </div>

        {((filters.status && filters.status.length > 0) || 
          (filters.priority && filters.priority.length > 0) ||
          (filters.category && filters.category.length > 0) ||
          (filters.assignedTo && filters.assignedTo.length > 0) ||
          (filters.assignedGroup && filters.assignedGroup.length > 0) ||
          filters.dateFrom ||
          filters.dateTo) && (
          <div className="flex flex-wrap gap-2 mt-4">
            {filters.status?.map((statusId) => (
              <Badge
                key={`status-${statusId}`}
                variant="secondary"
                className="gap-1"
                data-testid={`badge-status-filter-${statusId}`}
              >
                {statusLabels[statusId]}
                <X
                  className="h-3 w-3 cursor-pointer"
                  onClick={() => handleStatusChange(statusId.toString())}
                />
              </Badge>
            ))}
            {filters.priority?.map((priorityId) => (
              <Badge
                key={`priority-${priorityId}`}
                variant="secondary"
                className="gap-1"
                data-testid={`badge-priority-filter-${priorityId}`}
              >
                {priorityLabels[priorityId]}
                <X
                  className="h-3 w-3 cursor-pointer"
                  onClick={() => handlePriorityChange(priorityId.toString())}
                />
              </Badge>
            ))}
            {filters.category?.map((categoryId) => (
              <Badge
                key={`category-${categoryId}`}
                variant="secondary"
                className="gap-1"
                data-testid={`badge-category-filter-${categoryId}`}
              >
                {categoryLabels[categoryId] || `Categoria ${categoryId}`}
                <X
                  className="h-3 w-3 cursor-pointer"
                  onClick={() => handleCategoryChange(categoryId.toString())}
                />
              </Badge>
            ))}
            {filters.assignedTo?.map((userId) => {
              const user = users.find(u => u.id === userId);
              return (
                <Badge
                  key={`assigned-${userId}`}
                  variant="secondary"
                  className="gap-1"
                  data-testid={`badge-assigned-filter-${userId}`}
                >
                  {user?.name || `Usuário ${userId}`}
                  <X
                    className="h-3 w-3 cursor-pointer"
                    onClick={() => handleAssignedToChange(userId.toString())}
                  />
                </Badge>
              );
            })}
            {filters.assignedGroup?.map((groupId) => {
              const group = groups.find(g => g.id === groupId);
              return (
                <Badge
                  key={`group-${groupId}`}
                  variant="secondary"
                  className="gap-1"
                  data-testid={`badge-group-filter-${groupId}`}
                >
                  {group?.name || `Grupo ${groupId}`}
                  <X
                    className="h-3 w-3 cursor-pointer"
                    onClick={() => handleAssignedGroupChange(groupId.toString())}
                  />
                </Badge>
              );
            })}
            {filters.dateFrom && (
              <Badge
                variant="secondary"
                className="gap-1"
                data-testid="badge-date-from-filter"
              >
                De: {format(new Date(filters.dateFrom), "dd/MM/yyyy", { locale: ptBR })}
                <X
                  className="h-3 w-3 cursor-pointer"
                  onClick={handleClearDateFrom}
                />
              </Badge>
            )}
            {filters.dateTo && (
              <Badge
                variant="secondary"
                className="gap-1"
                data-testid="badge-date-to-filter"
              >
                Até: {format(new Date(filters.dateTo), "dd/MM/yyyy", { locale: ptBR })}
                <X
                  className="h-3 w-3 cursor-pointer"
                  onClick={handleClearDateTo}
                />
              </Badge>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
