import { getGlpiClient } from "./glpi-client";
import type { GlpiTicket, TicketFilters, TicketStats } from "@shared/schema";

export class TicketService {
  private glpiClient = getGlpiClient();

  private applyInMemoryFilters(tickets: GlpiTicket[], filters: TicketFilters): GlpiTicket[] {
    let filteredTickets = tickets;

    if (filters.search) {
      const searchLower = filters.search.toLowerCase();
      filteredTickets = filteredTickets.filter(t => 
        t.name?.toLowerCase().includes(searchLower) || 
        t.content?.toLowerCase().includes(searchLower)
      );
    }

    if (filters.status && filters.status.length > 0) {
      filteredTickets = filteredTickets.filter(t => 
        filters.status!.includes(t.status)
      );
    }

    if (filters.priority && filters.priority.length > 0) {
      filteredTickets = filteredTickets.filter(t => 
        filters.priority!.includes(t.priority)
      );
    }

    if (filters.type && filters.type.length > 0) {
      filteredTickets = filteredTickets.filter(t => 
        filters.type!.includes(t.type)
      );
    }

    if (filters.category && filters.category.length > 0) {
      filteredTickets = filteredTickets.filter(t => 
        t.itilcategories_id && filters.category!.includes(t.itilcategories_id)
      );
    }

    if (filters.dateFrom) {
      const fromDate = new Date(filters.dateFrom);
      filteredTickets = filteredTickets.filter(t => 
        new Date(t.date) >= fromDate
      );
    }

    if (filters.dateTo) {
      const toDate = new Date(filters.dateTo);
      toDate.setHours(23, 59, 59, 999); // Include the entire day
      filteredTickets = filteredTickets.filter(t => 
        new Date(t.date) <= toDate
      );
    }

    if (filters.assignedTo && filters.assignedTo.length > 0) {
      filteredTickets = filteredTickets.filter(t => 
        t.users_id_assign && filters.assignedTo!.includes(t.users_id_assign)
      );
    }

    if (filters.assignedGroup && filters.assignedGroup.length > 0) {
      filteredTickets = filteredTickets.filter(t => 
        t.groups_id_assign && filters.assignedGroup!.includes(t.groups_id_assign)
      );
    }

    return filteredTickets;
  }

  async getTickets(filters: TicketFilters, page: number = 1, limit: number = 20): Promise<GlpiTicket[]> {
    // For filtered requests that require in-memory filtering,
    // we need to fetch ALL tickets first because GLPI API doesn't reliably apply all filter criteria
    const needsInMemoryFiltering = filters.category?.length || filters.assignedTo?.length || 
                                   filters.assignedGroup?.length || filters.dateFrom || filters.dateTo;
    
    if (needsInMemoryFiltering) {
      // Fetch ALL tickets without pagination
      const allTickets = await this.getAllTickets({});
      
      // Apply filters in memory
      const filteredTickets = this.applyInMemoryFilters(allTickets, filters);
      
      // Apply pagination to filtered results
      const start = (page - 1) * limit;
      const end = start + limit;
      return filteredTickets.slice(start, end);
    }

    // For simple queries (status, priority, type, search), use GLPI API filters
    const criteria: any[] = [];
    
    if (filters.search) {
      criteria.push({
        field: 1, // Name field
        searchtype: "contains",
        value: filters.search,
      });
    }

    if (filters.status && filters.status.length > 0) {
      filters.status.forEach(status => {
        criteria.push({
          field: 12, // Status field
          searchtype: "equals",
          value: status,
          link: "OR",
        });
      });
    }

    if (filters.priority && filters.priority.length > 0) {
      filters.priority.forEach(priority => {
        criteria.push({
          field: 3, // Priority field
          searchtype: "equals",
          value: priority,
          link: "OR",
        });
      });
    }

    if (filters.type && filters.type.length > 0) {
      filters.type.forEach(type => {
        criteria.push({
          field: 14, // Type field
          searchtype: "equals",
          value: type,
          link: "OR",
        });
      });
    }

    const start = (page - 1) * limit;
    const end = start + limit - 1;
    const range = `${start}-${end}`;

    const tickets = await this.glpiClient.getTickets({
      range,
      criteria: criteria.length > 0 ? criteria : undefined,
    });

    return tickets as GlpiTicket[];
  }

  async getAllTickets(filters: TicketFilters): Promise<GlpiTicket[]> {
    // Fetch ALL tickets by paging through results
    let allTickets: GlpiTicket[] = [];
    let page = 1;
    const pageSize = 200;
    let hasMore = true;

    while (hasMore) {
      const batch = await this.getTickets(filters, page, pageSize);
      if (batch.length === 0) {
        hasMore = false;
      } else {
        allTickets = allTickets.concat(batch);
        if (batch.length < pageSize) {
          hasMore = false; // Last page
        }
        page++;
      }
      // Safety limit to prevent infinite loops
      if (page > 100) break; // Max 20,000 tickets
    }

    return allTickets;
  }

  async getStats(filters: TicketFilters): Promise<TicketStats> {
    // Fetch ALL tickets with the same filters applied
    const allTickets = await this.getAllTickets(filters);

    // Apply additional in-memory filters for accuracy
    const filteredTickets = this.applyInMemoryFilters(allTickets, filters);

    // Calculate stats
    const total = filteredTickets.length;
    const newTickets = filteredTickets.filter(t => t.status === 1).length;
    const inProgress = filteredTickets.filter(t => t.status === 2).length;
    const pending = filteredTickets.filter(t => t.status === 3).length;
    const solved = filteredTickets.filter(t => t.status === 4).length;
    const closed = filteredTickets.filter(t => t.status === 5).length;

    // Group by status
    const statusCounts = new Map<number, number>();
    for (let i = 1; i <= 5; i++) {
      statusCounts.set(i, 0);
    }
    filteredTickets.forEach(t => {
      statusCounts.set(t.status, (statusCounts.get(t.status) || 0) + 1);
    });

    const byStatus = Array.from(statusCounts.entries()).map(([status, count]) => ({
      status,
      count,
    }));

    // Group by priority
    const priorityCounts = new Map<number, number>();
    for (let i = 1; i <= 6; i++) {
      priorityCounts.set(i, 0);
    }
    filteredTickets.forEach(t => {
      priorityCounts.set(t.priority, (priorityCounts.get(t.priority) || 0) + 1);
    });

    const byPriority = Array.from(priorityCounts.entries()).map(([priority, count]) => ({
      priority,
      count,
    }));

    // Group by type
    const typeCounts = new Map<number, number>();
    for (let i = 1; i <= 2; i++) {
      typeCounts.set(i, 0);
    }
    filteredTickets.forEach(t => {
      typeCounts.set(t.type, (typeCounts.get(t.type) || 0) + 1);
    });

    const byType = Array.from(typeCounts.entries()).map(([type, count]) => ({
      type,
      count,
    }));

    // Create timeline (last 7 days)
    const timeline: { date: string; count: number }[] = [];
    const today = new Date();
    for (let i = 6; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split("T")[0];
      
      const count = filteredTickets.filter(t => {
        const ticketDate = new Date(t.date).toISOString().split("T")[0];
        return ticketDate === dateStr;
      }).length;

      timeline.push({
        date: dateStr,
        count,
      });
    }

    // Calculate time-based metrics
    let totalFirstResponseTime = 0;
    let firstResponseCount = 0;
    let totalResolutionTime = 0;
    let resolutionCount = 0;
    let totalWaitingTime = 0;
    let waitingCount = 0;
    let slaCompliant = 0;
    let slaViolated = 0;
    let slaTotal = 0;

    filteredTickets.forEach(t => {
      // First response time
      if (t.takeintoaccount_delay_stat && t.takeintoaccount_delay_stat > 0) {
        totalFirstResponseTime += t.takeintoaccount_delay_stat;
        firstResponseCount++;
      }

      // Resolution time (from creation to solve)
      if (t.solve_delay_stat && t.solve_delay_stat > 0) {
        totalResolutionTime += t.solve_delay_stat;
        resolutionCount++;
      }

      // Waiting time
      if (t.waiting_duration && t.waiting_duration > 0) {
        totalWaitingTime += t.waiting_duration;
        waitingCount++;
      }

      // SLA compliance
      if (t.time_to_resolve && t.solvedate) {
        slaTotal++;
        try {
          const slaDate = new Date(t.time_to_resolve.replace(" ", "T"));
          const solveDate = new Date(t.solvedate.replace(" ", "T"));
          if (solveDate <= slaDate) {
            slaCompliant++;
          } else {
            slaViolated++;
          }
        } catch (e) {
          // Invalid date, skip
        }
      }
    });

    const avgFirstResponseTime = firstResponseCount > 0 ? Math.round(totalFirstResponseTime / firstResponseCount) : undefined;
    const avgResolutionTime = resolutionCount > 0 ? Math.round(totalResolutionTime / resolutionCount) : undefined;
    const avgWaitingTime = waitingCount > 0 ? Math.round(totalWaitingTime / waitingCount) : undefined;
    const ticketsInWaiting = filteredTickets.filter(t => t.status === 3).length;
    const slaCompliance = slaTotal > 0 ? Math.round((slaCompliant / slaTotal) * 100) : undefined;

    // Group by assignee
    const assigneeCounts = new Map<number, { name: string; count: number }>();
    const userNameCache = new Map<number, string>();
    
    filteredTickets.forEach(t => {
      if (t.users_id_assign) {
        const current = assigneeCounts.get(t.users_id_assign) || { name: `User ${t.users_id_assign}`, count: 0 };
        assigneeCounts.set(t.users_id_assign, { name: current.name, count: current.count + 1 });
      }
    });

    const byAssignee = Array.from(assigneeCounts.entries()).map(([userId, data]) => ({
      userId,
      userName: data.name,
      count: data.count,
    }));

    // Group by group
    const groupCounts = new Map<number, { name: string; count: number }>();
    
    filteredTickets.forEach(t => {
      if (t.groups_id_assign) {
        const current = groupCounts.get(t.groups_id_assign) || { name: `Group ${t.groups_id_assign}`, count: 0 };
        groupCounts.set(t.groups_id_assign, { name: current.name, count: current.count + 1 });
      }
    });

    const byGroup = Array.from(groupCounts.entries()).map(([groupId, data]) => ({
      groupId,
      groupName: data.name,
      count: data.count,
    }));

    // Resolution time distribution
    const resolutionTimeDistribution = [
      { range: "< 1h", count: 0 },
      { range: "1-4h", count: 0 },
      { range: "4-8h", count: 0 },
      { range: "8-24h", count: 0 },
      { range: "1-3d", count: 0 },
      { range: "> 3d", count: 0 },
    ];

    filteredTickets.forEach(t => {
      if (t.solve_delay_stat) {
        const hours = t.solve_delay_stat / 3600;
        if (hours < 1) resolutionTimeDistribution[0].count++;
        else if (hours < 4) resolutionTimeDistribution[1].count++;
        else if (hours < 8) resolutionTimeDistribution[2].count++;
        else if (hours < 24) resolutionTimeDistribution[3].count++;
        else if (hours < 72) resolutionTimeDistribution[4].count++;
        else resolutionTimeDistribution[5].count++;
      }
    });

    // Create weekly timeline (last 8 weeks)
    const weeklyTimeline: { weekLabel: string; startDate: string; endDate: string; count: number }[] = [];
    const todayForWeeks = new Date();
    
    for (let i = 7; i >= 0; i--) {
      // Calculate start of week (Monday)
      const weekStart = new Date(todayForWeeks);
      weekStart.setDate(weekStart.getDate() - (weekStart.getDay() === 0 ? 6 : weekStart.getDay() - 1)); // Go to Monday
      weekStart.setDate(weekStart.getDate() - (i * 7)); // Go back i weeks
      weekStart.setHours(0, 0, 0, 0);
      
      // Calculate end of week (Sunday)
      const weekEnd = new Date(weekStart);
      weekEnd.setDate(weekEnd.getDate() + 6);
      weekEnd.setHours(23, 59, 59, 999);
      
      const startDateStr = weekStart.toISOString().split("T")[0];
      const endDateStr = weekEnd.toISOString().split("T")[0];
      
      // Format week label (e.g., "14-20 Out")
      const months = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];
      const startDay = weekStart.getDate();
      const endDay = weekEnd.getDate();
      const month = months[weekEnd.getMonth()];
      const weekLabel = i === 0 ? "Esta Semana" : `${startDay}-${endDay} ${month}`;
      
      // Count tickets in this week
      const count = filteredTickets.filter(t => {
        const ticketDate = new Date(t.date);
        return ticketDate >= weekStart && ticketDate <= weekEnd;
      }).length;
      
      weeklyTimeline.push({
        weekLabel,
        startDate: startDateStr,
        endDate: endDateStr,
        count,
      });
    }

    return {
      total,
      new: newTickets,
      inProgress,
      pending,
      solved,
      closed,
      avgResolutionTime,
      avgFirstResponseTime,
      avgWaitingTime,
      ticketsInWaiting,
      slaCompliance,
      slaViolations: slaViolated,
      byStatus,
      byPriority,
      byType,
      byAssignee,
      byGroup,
      resolutionTimeDistribution,
      timeline,
      weeklyTimeline,
    };
  }
}

export const ticketService = new TicketService();
