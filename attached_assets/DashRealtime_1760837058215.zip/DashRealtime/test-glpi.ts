import axios from "axios";

// EDITE ESTES VALORES COM OS SEUS TOKENS CORRETOS:
const GLPI_API_URL = "https://chamados.jacontactcenter.com.br/apirest.php";
const GLPI_APP_TOKEN = "17ccgJFRfx8HaHSHCB0fhGvSEyMc4ZXjELBjATT0";  // ← EDITE AQUI
const GLPI_USER_TOKEN = "sSWgEpGhJlVjyVNLa7kIjxLUwuBG5gN1C5zqPDUM";  // ← EDITE AQUI

async function testGlpiConnection() {
  console.log("🔍 Testando conexão GLPI...\n");
  
  try {
    // Passo 1: Iniciar sessão
    console.log("Passo 1: Iniciando sessão com GLPI...");
    console.log(`URL: ${GLPI_API_URL}/initSession`);
    console.log(`App-Token: ${GLPI_APP_TOKEN}`);
    console.log(`User-Token: ${GLPI_USER_TOKEN}\n`);
    
    const sessionResponse = await axios.post(`${GLPI_API_URL}/initSession`, null, {
      headers: {
        "Content-Type": "application/json",
        "App-Token": GLPI_APP_TOKEN,
        "Authorization": `user_token ${GLPI_USER_TOKEN}`,
      },
    });
    
    const sessionToken = sessionResponse.data.session_token;
    console.log("✅ Sessão iniciada com sucesso!");
    console.log(`Session-Token: ${sessionToken}\n`);
    
    // Passo 2: Buscar tickets
    console.log("Passo 2: Buscando tickets...");
    const ticketsResponse = await axios.get(`${GLPI_API_URL}/Ticket/?range=0-9`, {
      headers: {
        "Content-Type": "application/json",
        "App-Token": GLPI_APP_TOKEN,
        "Session-Token": sessionToken,
      },
    });
    
    const tickets = Array.isArray(ticketsResponse.data) ? ticketsResponse.data : [];
    console.log(`✅ Encontrados ${tickets.length} tickets!`);
    
    if (tickets.length > 0) {
      console.log("\nPrimeiro ticket:");
      console.log(JSON.stringify(tickets[0], null, 2));
    }
    
    // Passo 3: Encerrar sessão
    console.log("\nPasso 3: Encerrando sessão...");
    await axios.get(`${GLPI_API_URL}/killSession`, {
      headers: {
        "App-Token": GLPI_APP_TOKEN,
        "Session-Token": sessionToken,
      },
    });
    console.log("✅ Sessão encerrada!\n");
    
    console.log("🎉 SUCESSO! Conexão com GLPI funcionando perfeitamente!");
    console.log("\nAgora você pode atualizar as secrets do Replit com estes valores:");
    console.log(`GLPI_APP_TOKEN=${GLPI_APP_TOKEN}`);
    console.log(`GLPI_USER_TOKEN=${GLPI_USER_TOKEN}`);
    
  } catch (error: any) {
    console.error("\n❌ ERRO ao conectar com GLPI:");
    if (error.response) {
      console.error("Status:", error.response.status);
      console.error("Dados:", JSON.stringify(error.response.data, null, 2));
      console.error("Headers:", error.response.headers);
    } else {
      console.error(error.message);
    }
  }
}

testGlpiConnection();
