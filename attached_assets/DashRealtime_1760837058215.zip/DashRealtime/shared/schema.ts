import { z } from "zod";

// GLPI Ticket Schema based on API structure
export const glpiTicketSchema = z.object({
  id: z.number(),
  name: z.string(),
  content: z.string().optional(),
  status: z.number(), // 1=New, 2=Processing, 3=Pending, 4=Solved, 5=Closed
  urgency: z.number(), // 1-5
  impact: z.number(), // 1-5
  priority: z.number(), // 1-6
  type: z.number(), // 1=Incident, 2=Request
  date: z.string(),
  date_mod: z.string(),
  entities_id: z.number(),
  itilcategories_id: z.number().optional(),
  users_id_recipient: z.number().optional(),
  locations_id: z.number().optional(),
  requesttypes_id: z.number().optional(),
  
  // Assignment fields
  users_id_assign: z.number().optional(),
  groups_id_assign: z.number().optional(),
  users_id_lastupdater: z.number().optional(),
  
  // Date fields for time tracking
  closedate: z.string().nullable().optional(),
  solvedate: z.string().nullable().optional(),
  time_to_resolve: z.string().nullable().optional(),
  time_to_own: z.string().nullable().optional(),
  begin_waiting_date: z.string().nullable().optional(),
  
  // Time metrics (in seconds)
  waiting_duration: z.number().optional(),
  actiontime: z.number().optional(),
  takeintoaccount_delay_stat: z.number().optional(),
  solve_delay_stat: z.number().optional(),
  close_delay_stat: z.number().optional(),
  
  // SLA/OLA fields
  slas_id_ttr: z.number().optional(),
  slas_id_tto: z.number().optional(),
  olas_id_ttr: z.number().optional(),
  olas_id_tto: z.number().optional(),
  
  // Validation
  global_validation: z.number().optional(),
});

export type GlpiTicket = z.infer<typeof glpiTicketSchema>;

// Filter schema
export const ticketFiltersSchema = z.object({
  status: z.array(z.number()).optional(),
  priority: z.array(z.number()).optional(),
  category: z.array(z.number()).optional(),
  search: z.string().optional(),
  dateFrom: z.string().optional(),
  dateTo: z.string().optional(),
  type: z.array(z.number()).optional(),
  assignedTo: z.array(z.number()).optional(),
  assignedGroup: z.array(z.number()).optional(),
});

export type TicketFilters = z.infer<typeof ticketFiltersSchema>;

// Stats schema for KPI cards
export const ticketStatsSchema = z.object({
  total: z.number(),
  new: z.number(),
  inProgress: z.number(),
  pending: z.number(),
  solved: z.number(),
  closed: z.number(),
  
  // Time-based metrics
  avgResolutionTime: z.number().optional(),
  avgFirstResponseTime: z.number().optional(),
  avgWaitingTime: z.number().optional(),
  ticketsInWaiting: z.number().optional(),
  
  // SLA metrics
  slaCompliance: z.number().optional(),
  slaViolations: z.number().optional(),
  
  byStatus: z.array(z.object({
    status: z.number(),
    count: z.number(),
  })),
  byPriority: z.array(z.object({
    priority: z.number(),
    count: z.number(),
  })),
  byType: z.array(z.object({
    type: z.number(),
    count: z.number(),
  })),
  byAssignee: z.array(z.object({
    userId: z.number(),
    userName: z.string(),
    count: z.number(),
  })).optional(),
  byGroup: z.array(z.object({
    groupId: z.number(),
    groupName: z.string(),
    count: z.number(),
  })).optional(),
  resolutionTimeDistribution: z.array(z.object({
    range: z.string(),
    count: z.number(),
  })).optional(),
  timeline: z.array(z.object({
    date: z.string(),
    count: z.number(),
  })),
  weeklyTimeline: z.array(z.object({
    weekLabel: z.string(), // e.g., "Sem 42" or "13-19 Out"
    startDate: z.string(),
    endDate: z.string(),
    count: z.number(),
  })).optional(),
});

export type TicketStats = z.infer<typeof ticketStatsSchema>;

// Helper functions for labels
export const statusLabels: Record<number, string> = {
  1: "Novo",
  2: "Em Andamento",
  3: "Pendente",
  4: "Resolvido",
  5: "Fechado",
};

export const priorityLabels: Record<number, string> = {
  1: "Muito Baixa",
  2: "Baixa",
  3: "Média",
  4: "Alta",
  5: "Muito Alta",
  6: "Crítica",
};

export const urgencyLabels: Record<number, string> = {
  1: "Muito Baixa",
  2: "Baixa",
  3: "Média",
  4: "Alta",
  5: "Muito Alta",
};

export const typeLabels: Record<number, string> = {
  1: "Incidente",
  2: "Solicitação",
};

// Helper function to format time duration (seconds to human readable)
export function formatDuration(seconds: number | undefined | null): string {
  if (!seconds || seconds === 0) return "-";
  
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  
  if (days > 0) return `${days}d ${hours}h`;
  if (hours > 0) return `${hours}h ${minutes}m`;
  return `${minutes}m`;
}

// Helper function to calculate SLA status
export function getSLAStatus(timeToResolve: string | null | undefined, solveDate: string | null | undefined): "ok" | "warning" | "violated" | "n/a" {
  if (!timeToResolve) return "n/a";
  if (!solveDate) return "n/a"; // Not solved yet
  
  try {
    const slaDate = new Date(timeToResolve.replace(" ", "T"));
    const solveDateParsed = new Date(solveDate.replace(" ", "T"));
    
    if (solveDateParsed <= slaDate) return "ok";
    return "violated";
  } catch {
    return "n/a";
  }
}
