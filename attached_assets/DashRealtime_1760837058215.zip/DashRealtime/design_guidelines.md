# GLPI Ticket Dashboard - Design Guidelines

## Design Approach
**Selected System**: Carbon Design System (IBM) with Modern Dashboard Patterns
**Justification**: Data-heavy enterprise application requiring clarity, hierarchy, and efficient information display. Carbon excels at complex data visualization while maintaining professional aesthetics.

## Core Design Principles
1. **Data First**: Every pixel serves information delivery
2. **Scannable Hierarchy**: Users should grasp status at a glance
3. **Responsive Density**: Adapt information density to viewport size
4. **Purposeful Color**: Color indicates status/priority, not decoration

---

## Color Palette

### Dark Mode (Primary)
- **Background**: 220 15% 8% (main), 220 12% 12% (elevated cards)
- **Surface**: 220 10% 16% (card backgrounds), 220 8% 20% (hover states)
- **Text**: 0 0% 98% (primary), 0 0% 70% (secondary), 0 0% 50% (tertiary)
- **Border**: 220 10% 22% (subtle separators)

### Light Mode
- **Background**: 0 0% 98%, 0 0% 100% (cards)
- **Surface**: 0 0% 96%, 220 10% 94% (hover)
- **Text**: 220 15% 15% (primary), 220 10% 40% (secondary)
- **Border**: 220 10% 88%

### Status Colors (Both Modes)
- **New/Open**: 210 100% 55% (blue)
- **In Progress**: 40 95% 55% (amber)
- **Pending**: 280 65% 60% (purple)
- **Solved**: 150 60% 50% (green)
- **Closed**: 0 0% 50% (gray)

### Priority Indicators
- **Very High**: 0 85% 60% (red)
- **High**: 25 95% 55% (orange)
- **Medium**: 210 100% 55% (blue)
- **Low**: 0 0% 60% (gray)

### Accent (Minimal Use)
- **Primary Action**: 210 100% 50%
- **Charts**: Use status colors for data series

---

## Typography

**Font Stack**: 
- Primary: 'Inter', system-ui, sans-serif (via Google Fonts)
- Monospace: 'JetBrains Mono' for ticket IDs, timestamps

**Scale**:
- **Page Title**: text-3xl font-semibold (30px)
- **Section Headers**: text-xl font-semibold (20px)
- **Card Titles**: text-base font-medium (16px)
- **Body/Data**: text-sm (14px)
- **Labels/Meta**: text-xs font-medium uppercase tracking-wide (12px)
- **Large Numbers (KPIs)**: text-4xl font-bold (36px)

---

## Layout System

**Spacing Primitives**: Use Tailwind units of **2, 4, 6, 8** consistently
- Component padding: p-4, p-6
- Section gaps: gap-4, gap-6
- Card spacing: space-y-6
- Grid gaps: gap-4

**Container Strategy**:
- Dashboard wrapper: max-w-screen-2xl mx-auto px-4 lg:px-8
- Sidebar (if used): w-64 fixed
- Main content: Dynamic width with min-width constraints

**Grid Layouts**:
- KPI Cards: grid-cols-1 md:grid-cols-2 lg:grid-cols-4
- Charts: grid-cols-1 lg:grid-cols-2
- Filters: Horizontal flex layout with gap-4

---

## Component Library

### Dashboard Header
- Logo/Title on left
- Real-time status indicator (pulsing dot + "Updated 5s ago")
- Refresh button + Auto-refresh toggle
- User avatar/settings on right
- Height: 16 (64px), border-b with subtle shadow

### KPI Cards (4 across on desktop)
- Rounded corners: rounded-lg
- Padding: p-6
- Large number display with trend indicator (↑↓)
- Label below in muted text
- Optional sparkline mini-chart
- Subtle hover lift effect

### Filter Panel
- Sticky bar below header
- Multi-select dropdowns for: Status, Priority, Date Range, Category
- Search input with icon
- "Clear Filters" button on right
- Background slightly different from main bg

### Charts Section
- **Status Distribution**: Donut chart (Chart.js/Recharts)
- **Priority Breakdown**: Horizontal bar chart
- **Timeline**: Line chart showing ticket creation over time
- **Type Distribution**: Simple bar chart
- Each chart in card with title and last-update timestamp

### Data Table
- Zebra striping for rows (subtle)
- Sticky header row
- Columns: ID (mono), Title, Status (badge), Priority (badge), Created, Assignee
- Status badges: rounded-full px-3 py-1 text-xs with status colors
- Pagination at bottom: page numbers + items per page selector
- Hover effect on rows
- Sort indicators on column headers

### Empty States
- Centered illustration placeholder
- Helpful message: "No tickets match your filters"
- "Clear filters" action button

---

## Interactions & Animations

**Minimize Animations** - Use only for:
- Loading states: Subtle skeleton screens
- Real-time updates: Brief highlight flash on new data
- Hover states: Smooth scale/shadow transitions (150ms)
- Chart transitions: Data point animations on load (500ms ease-out)

**No**: Page transitions, scroll-triggered animations, excessive micro-interactions

---

## Responsive Strategy

**Desktop (lg+)**: 
- 4-column KPI cards
- 2-column chart grid
- Full table with all columns

**Tablet (md)**:
- 2-column KPI cards
- Single column charts
- Table scrolls horizontally

**Mobile (base)**:
- Single column everything
- Stack filters vertically
- Simplified table (key columns only)
- Bottom navigation if needed

---

## Data Visualization Rules

1. **Color Coding**: Always use status/priority colors consistently
2. **Tooltips**: On hover, show detailed data (Chart.js default styling)
3. **Legends**: Position below charts, horizontal layout
4. **Axis Labels**: Always visible, rotated if needed
5. **Data Density**: Show meaningful aggregations, not raw dumps

---

## Critical Dashboard-Specific Patterns

- **Real-time Indicator**: Visible pulsing green dot + timestamp in top-right
- **Skeleton Loading**: During data fetch, show gray pulsing boxes matching layout
- **Error States**: Red banner at top with retry button
- **Badge System**: Consistent pill-shaped badges for status/priority throughout
- **Monospace IDs**: All ticket IDs in monospace font for scannability
- **Density Toggle**: Option to switch between compact/comfortable row spacing

---

## Images
**No hero images** - This is a utility dashboard where every pixel shows data. Use icons from Heroicons for:
- Filter icons (funnel, search, calendar)
- Status indicators
- Empty state illustrations (optional simple SVG)
- Chart type selectors