import { useQuery } from "@tanstack/react-query";
import { BiForm } from "@/components/bi-form";
import { BiTable } from "@/components/bi-table";
import { BiCanvas } from "@/components/bi-canvas";
import { ThemeToggle } from "@/components/theme-toggle";
import type { BiWithBases } from "@shared/schema";

export default function Home() {
  const { data: bisData, isLoading } = useQuery<BiWithBases[]>({
    queryKey: ["/api/bis"],
  });

  const bisEmAberto = bisData?.filter((bi) => bi.status === "em_aberto" && !bi.inativo) || [];
  const bisConcluidos = bisData?.filter((bi) => bi.status === "concluido" && !bi.inativo) || [];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="max-w-[1600px] mx-auto px-6 py-6 flex items-center justify-between">
          <h1 className="text-[28px] font-semibold text-foreground">
            Base de dados Power BI
          </h1>
          <ThemeToggle />
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-[1600px] mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-[420px_1fr] gap-6">
          {/* Left Panel - Form */}
          <div className="lg:sticky lg:top-8 lg:self-start">
            <BiForm />
          </div>

          {/* Right Panel - Tables */}
          <div className="space-y-8">
            {/* BIs em Aberto */}
            <div>
              <h2 className="text-[20px] font-semibold text-foreground mb-4">
                BIs em Aberto
              </h2>
              <BiTable
                bis={bisEmAberto}
                isLoading={isLoading}
                type="em_aberto"
              />
            </div>

            {/* BIs Concluídos */}
            <div>
              <h2 className="text-[20px] font-semibold text-foreground mb-4">
                BIs Concluídos
              </h2>
              <BiTable
                bis={bisConcluidos}
                isLoading={isLoading}
                type="concluido"
              />
            </div>
          </div>
        </div>

        {/* Canvas Section */}
        <div className="mt-12 pt-8 border-t border-border">
          <h2 className="text-[20px] font-semibold text-foreground mb-4">
            Planejamento de BIs
          </h2>
          <BiCanvas />
        </div>
      </main>
    </div>
  );
}
