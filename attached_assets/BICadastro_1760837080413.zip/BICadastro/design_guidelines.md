# Design Guidelines: Power BI Demand Control Application

## Design Approach
**Selected Approach:** Design System + Reference-Based Hybrid
- **Base System:** Material Design (for data-dense, information-heavy applications)
- **References:** Linear (clean aesthetics, modern tables), Notion (form interactions, database views)
- **Rationale:** This is a utility-focused productivity tool requiring clarity, efficiency, and robust data handling

## Core Design Principles
1. **Information Hierarchy:** Clear visual separation between form input, active work, and completed items
2. **Data Density Balance:** Maximize information display without overwhelming users
3. **Progressive Disclosure:** Expandable sections for detailed data (origem tables) to keep main view clean
4. **Status-Driven Design:** Visual indicators make status immediately scannable

## Color Palette

**Dark Mode (Primary):**
- Background Primary: 220 15% 12%
- Background Secondary: 220 15% 16%
- Background Tertiary: 220 15% 20%
- Text Primary: 220 10% 95%
- Text Secondary: 220 10% 70%
- Primary Brand: 210 100% 60% (Blue - trust, data, clarity)
- Success: 142 76% 45%
- Warning: 38 92% 50%
- Error: 0 84% 60%
- Border: 220 15% 25%

**Light Mode:**
- Background Primary: 0 0% 100%
- Background Secondary: 220 15% 98%
- Text Primary: 220 15% 15%
- Primary Brand: 210 100% 50%

## Typography
- **Font Family:** Inter (primary), SF Pro (fallback) via Google Fonts CDN
- **Headings:** 
  - H1: 28px/600 (page title "Base de dados power BI")
  - H2: 20px/600 (section headers)
  - H3: 16px/600 (table headers, form labels)
- **Body:** 14px/400 (forms, table content)
- **Small:** 12px/400 (helper text, timestamps)

## Layout System
**Spacing Primitives:** Use Tailwind units of 2, 3, 4, 6, 8, 12, 16
- Container padding: p-6 to p-8
- Card spacing: p-4 to p-6
- Element gaps: gap-4, gap-6
- Section margins: mb-8, mt-6

**Grid Structure:**
- Main container: max-w-[1600px] mx-auto
- Left panel (Form): w-full lg:w-[420px] fixed height with scroll
- Right panel (Tables): flex-1 space-y-8
- Canvas area: Full width below, min-h-[500px]

## Component Library

### Form Components
- **Input Fields:** Material Design outlined style with floating labels
  - Border: 1px border-border, focus:border-primary with 2px
  - Padding: px-3 py-2
  - Dark mode compatible with proper background
- **Date Pickers:** Calendar icon, dropdown with date grid
- **Select Dropdowns:** Chevron icon, smooth dropdown animation
- **Dynamic Table (Origem):** Add/remove rows with icon buttons, clean row borders

### Table Components
- **Main Tables:** 
  - Header: Sticky, background-secondary, font-semibold
  - Rows: Hover effect (background change), border-b
  - Cells: py-3 px-4 alignment
- **Expandable Sections:** 
  - Chevron icon rotation animation
  - Nested table with subtle background difference
  - Smooth height transition
- **Status Badges:** 
  - Pill shape (rounded-full px-3 py-1)
  - Color coded: Aguardando(blue), Em Andamento(yellow), Pendente(orange), Concluído(green)

### Action Buttons
- **Primary:** Solid blue, px-4 py-2, rounded-md
- **Secondary:** Outlined, transparent background with border
- **Icon Buttons:** Square 36px, centered icon, hover background
- **Inativar Button:** Ghost red, appears on completed items

### Canvas/Miro-like Component
- **Toolbar:** Fixed top bar with tools (select, rectangle, connector, text)
- **Canvas:** Infinite scroll grid background, zoom controls
- **Nodes:** Draggable cards with title/content, connection points
- **Connectors:** Bezier curves between nodes, arrow endpoints
- **Controls:** Bottom-right: Zoom in/out, fit to screen, pan mode

## Interaction Patterns
- **Form Submission:** Loading state on button, success feedback with subtle notification
- **Table Row Expansion:** Smooth accordion animation (300ms ease)
- **Status Changes:** Dropdown or segmented control, immediate visual update
- **BI Completion Flow:** Auto-move from "Em Aberto" to "Concluídos" when all bases marked "Concluído"
- **Canvas Interactions:** Click to select, drag to move, double-click to edit

## Visual Hierarchy
- **Primary Focus:** Form cadastro (left) uses card elevation (shadow)
- **Secondary Focus:** BIs em Aberto table (prominent position, larger)
- **Tertiary:** Concluídos table (slightly muted, smaller text)
- **Supporting:** Canvas area (visually separated with border-t)

## Data Display Strategy
- **Compact but Readable:** 14px base, adequate line-height (1.5)
- **Responsive Tables:** Horizontal scroll on mobile, full display on desktop
- **Information Grouping:** Related fields in form groups with spacing
- **Progressive Detail:** Main info visible, detailed origem data behind click

## Accessibility & Usability
- All form inputs with clear labels and validation states
- Status indicators use both color and text for accessibility
- Keyboard navigation for all interactive elements
- Focus states clearly visible (ring-2 ring-primary/50)
- Canvas with keyboard shortcuts (Delete, Ctrl+Z, arrow keys for precision)