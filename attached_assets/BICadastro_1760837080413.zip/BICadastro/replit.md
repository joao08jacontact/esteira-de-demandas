# Base de dados Power BI

Sistema de controle interno de demandas Power BI desenvolvido com React, Express e TypeScript.

## Visão Geral

Aplicação web para gerenciar projetos de Business Intelligence (BI) com controle de status, bases de origem e planejamento visual através de fluxogramas.

## Estrutura do Projeto

### Frontend (React + TypeScript)
- **Home Page** (`client/src/pages/home.tsx`): Página principal com layout dividido
- **BiForm** (`client/src/components/bi-form.tsx`): Formulário de cadastro de novos BIs
- **BiTable** (`client/src/components/bi-table.tsx`): Tabelas de BIs em aberto e concluídos
- **BiCanvas** (`client/src/components/bi-canvas.tsx`): Canvas interativo para criar fluxogramas
- **CustomNode** (`client/src/components/custom-node.tsx`): Nós customizados para o canvas

### Backend (Express + TypeScript)
- **Schema** (`shared/schema.ts`): Modelos de dados compartilhados
- **Storage** (`server/storage.ts`): Interface de armazenamento em memória
- **Routes** (`server/routes.ts`): Rotas da API

## Funcionalidades

### 1. Cadastro de BIs
- Nome do projeto
- Datas de início e final
- Responsável e operação
- Tabela dinâmica de bases de origem com indicador de API

### 2. Gerenciamento de BIs
- **BIs em Aberto**: Lista de projetos ativos com controle de status das bases
- **BIs Concluídos**: Projetos finalizados com opção de inativar
- Sistema de status: Aguardando, Em Andamento, Pendente, Concluído
- Observações para pendências
- Transição automática de "Em Aberto" para "Concluído"

### 3. Canvas de Planejamento
- Criação de fluxogramas estilo Miro
- Elementos arrastavéis (caixas e texto)
- Conexões entre elementos
- Zoom e minimap
- Persistência automática

## Fluxo de Dados

1. **Criar BI**: Formulário → API POST `/api/bis` → Storage → Atualiza lista
2. **Atualizar Status**: Select → API PATCH `/api/bases/:id/status` → Storage → Recalcula status do BI
3. **Inativar BI**: Botão → API PATCH `/api/bis/:id/inativar` → Storage → Remove da visualização
4. **Canvas**: Drag & Drop → Auto-save → API POST `/api/canvas` → Storage

## Design System

- **Cores**: Sistema de cores adaptativo (light/dark mode)
- **Tipografia**: Inter (primary), SF Pro (fallback)
- **Componentes**: Shadcn UI + Tailwind CSS
- **Layout**: Responsivo com breakpoints para mobile/desktop
- **Status**: Badges coloridos para identificação visual rápida

## Tecnologias

- **Frontend**: React 18, TypeScript, TanStack Query, React Flow, Wouter, Shadcn UI
- **Backend**: Express.js, TypeScript
- **Styling**: Tailwind CSS
- **Forms**: React Hook Form + Zod validation
- **Storage**: In-memory (MemStorage)

## Arquitetura

```
┌─────────────────┬─────────────────────────────┐
│  Formulário     │  Tabelas                    │
│  (Cadastro)     │  ├─ BIs em Aberto          │
│                 │  └─ BIs Concluídos          │
└─────────────────┴─────────────────────────────┘
┌───────────────────────────────────────────────┐
│  Canvas de Planejamento (Fluxogramas)         │
└───────────────────────────────────────────────┘
```

## Data Models

### BI (Business Intelligence)
- id, nome, dataInicio, dataFinal, responsavel, operacao
- status: "em_aberto" | "concluido"
- inativo: boolean

### Base de Origem
- id, biId, nomeBase, temApi
- status: "aguardando" | "em_andamento" | "pendente" | "concluido"
- observacao (para pendências)

### Canvas Elements
- Nodes: elementos visuais com posição e conteúdo
- Edges: conexões entre nodes

## Recent Changes

- 2025-10-16: Projeto criado e completado com sucesso
- Schema definido para BIs, Bases de Origem e Canvas
- Frontend implementado com design profissional seguindo guidelines
- Backend completo com storage em memória e rotas API
- Sistema de formulários com validação React Hook Form + Zod
- Canvas interativo com React Flow e persistência automática
- Transição automática de BIs quando todas as bases são concluídas
- Testes e2e passando com sucesso
- Correção de bug de persistência do canvas usando refs
- Correção de bug de invalidação de queries do React Query

## Testes Realizados

✅ Cadastro de BIs com múltiplas bases de origem
✅ Visualização e expansão de detalhes das bases
✅ Atualização de status das bases (Aguardando → Em Andamento → Pendente → Concluído)
✅ Transição automática de BIs para "Concluídos" quando todas as bases são finalizadas
✅ Inativação de BIs concluídos
✅ Canvas: adicionar caixas e textos, mover elementos, conectar nós
✅ Persistência completa do canvas após reload da página
